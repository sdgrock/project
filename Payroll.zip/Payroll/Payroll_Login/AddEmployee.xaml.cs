﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollManagementEntity;
using PayrollManagementException;
using PayrollManagementBal;

namespace Payroll_Login
{
    /// <summary>
    /// Interaction logic for AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        public AddEmployee()
        {
            InitializeComponent();
        }


        //******************  Add Button Functionalities **********************//
        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CEmployeeMaster newEmployee = new CEmployeeMaster();
                newEmployee.FirstName = txtfname.Text;
                newEmployee.LastName = txtlname.Text;
                newEmployee.DOJ = Convert.ToDateTime(doj.Text);
                newEmployee.Address = txtaddr.Text;
                newEmployee.Password = txtpwd.Password.ToString();


                bool status = CEmployeeBAL.AddEmployeeBL(newEmployee);

                if (status)
                {
                    MessageBox.Show("Employee Added");   //When data is added correctly
                    txtfname.Text = "";
                    txtlname.Text = "";
                    doj.Text = "";
                    txtaddr.Text = "";
                    txtpwd.Password = "";
                    //GetAllGuest();
                }
                else
                {
                    MessageBox.Show("Employee Not added");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //******************  End  **********************//
    }
}
