﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementEntity
{
    public class CPayrollMaster
    {
        public int EmployeeID { get; set; }
        public string Designation { get; set; }
        public string Grade { get; set; }
        public decimal Salary { get; set; }
       

    }
}
