﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementEntity
{
    public class CLeaveMaster
    {
        public int EmployeeID { get; set; }
        public int LeaveAvailable { get; set; }
        public int LeavesAvailed { get; set; }
        public int LeavesBalance { get; set; }
    }
}
